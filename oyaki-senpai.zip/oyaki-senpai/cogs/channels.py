import discord
from discord.ext import commands


class Channels(commands.Cog):
    """Create, edit, delete and lock/unlock channels."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.group(invoke_without_command=True)
    async def channel(self, ctx: commands.Context):
        await ctx.send_help(ctx.command)

    @channel.command(name="create")
    async def create(
        self,
        ctx: commands.Context,
        ch_type: str,
        name: str,
        category: discord.CategoryChannel = None,
    ):
        """.channel create <text|voice|category> <name> [category]"""
        ch_type = ch_type.lower()
        if ch_type in ("text", "txt"):
            new_ch = await ctx.guild.create_text_channel(name, category=category)
        elif ch_type in ("voice", "vc"):
            new_ch = await ctx.guild.create_voice_channel(name, category=category)
        elif ch_type in ("category", "cat"):
            new_ch = await ctx.guild.create_category(name)
        else:
            await ctx.send("⚠️ Type must be `text`, `voice`, or `category`.")
            return
        mention = getattr(new_ch, "mention", f"`{new_ch.name}`")
        await ctx.send(f"✅ Created {mention}")

    @channel.command(name="delete")
    async def delete(self, ctx: commands.Context, channel: discord.abc.GuildChannel):
        """.channel delete <#channel>"""
        name = channel.name
        await channel.delete(reason=f"Deleted via bot by {ctx.author}")
        await ctx.send(f"🗑️ Deleted `{name}`")

    @channel.command(name="rename")
    async def rename(
        self, ctx: commands.Context, channel: discord.abc.GuildChannel, *, new_name: str
    ):
        """.channel rename <#channel> <new name>"""
        old = channel.name
        await channel.edit(name=new_name)
        await ctx.send(f"✏️ Renamed `{old}` → `{new_name}`")

    @channel.command(name="topic")
    async def topic(self, ctx: commands.Context, channel: discord.TextChannel, *, text: str):
        """.channel topic <#channel> <new topic>"""
        await channel.edit(topic=text)
        await ctx.send(f"✅ Updated topic for {channel.mention}")

    @channel.command(name="slowmode")
    async def slowmode(self, ctx: commands.Context, channel: discord.TextChannel, seconds: int):
        """.channel slowmode <#channel> <seconds>"""
        await channel.edit(slowmode_delay=seconds)
        await ctx.send(f"🐌 Slowmode for {channel.mention} set to {seconds}s")

    @channel.command(name="nsfw")
    async def nsfw(self, ctx: commands.Context, channel: discord.TextChannel, value: bool):
        """.channel nsfw <#channel> <true|false>"""
        await channel.edit(nsfw=value)
        await ctx.send(f"✅ NSFW for {channel.mention} set to `{value}`")

    @channel.command(name="move")
    async def move(
        self,
        ctx: commands.Context,
        channel: discord.abc.GuildChannel,
        category: discord.CategoryChannel,
    ):
        """.channel move <#channel> <category>"""
        await channel.edit(category=category)
        await ctx.send(f"📁 Moved `{channel.name}` into `{category.name}`")

    @channel.command(name="lock")
    async def lock(self, ctx: commands.Context, channel: discord.TextChannel = None):
        """.channel lock [#channel]  — denies @everyone Send Messages"""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(f"🔒 Locked {channel.mention}")

    @channel.command(name="unlock")
    async def unlock(self, ctx: commands.Context, channel: discord.TextChannel = None):
        """.channel unlock [#channel]"""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(f"🔓 Unlocked {channel.mention}")

    @channel.command(name="list")
    async def list_channels(self, ctx: commands.Context):
        """.channel list — shows every channel grouped by category"""
        categories: dict[str, list[str]] = {}
        for ch in ctx.guild.channels:
            if isinstance(ch, discord.CategoryChannel):
                continue
            cat_name = ch.category.name if ch.category else "No Category"
            categories.setdefault(cat_name, []).append(ch.name)

        lines = [f"**{cat}**: " + ", ".join(chs) for cat, chs in categories.items()]
        embed = discord.Embed(
            title=f"Channels in {ctx.guild.name}",
            description="\n".join(lines)[:4000] or "No channels.",
            colour=discord.Colour.blurple(),
        )
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Channels(bot))
