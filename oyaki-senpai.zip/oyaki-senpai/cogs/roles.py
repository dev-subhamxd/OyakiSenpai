import discord
from discord.ext import commands

# Names of every valid permission flag (send_messages, view_channel, etc.)
VALID_PERMS = set(discord.Permissions.VALID_FLAGS.keys())


class Roles(commands.Cog):
    """Create/edit/delete roles, and manage per-channel permission overwrites."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.group(invoke_without_command=True)
    async def role(self, ctx: commands.Context):
        await ctx.send_help(ctx.command)

    @role.command(name="create")
    async def create(
        self,
        ctx: commands.Context,
        name: str,
        color: str = None,
        hoist: bool = False,
        mentionable: bool = False,
    ):
        """.role create <name> [hex_color] [hoist] [mentionable]"""
        colour = discord.Colour(int(color.lstrip("#"), 16)) if color else discord.Colour.default()
        new_role = await ctx.guild.create_role(
            name=name, colour=colour, hoist=hoist, mentionable=mentionable
        )
        await ctx.send(f"✅ Created role {new_role.mention}")

    @role.command(name="delete")
    async def delete(self, ctx: commands.Context, role: discord.Role):
        """.role delete <@role>"""
        name = role.name
        await role.delete()
        await ctx.send(f"🗑️ Deleted role `{name}`")

    @role.command(name="rename")
    async def rename(self, ctx: commands.Context, role: discord.Role, *, new_name: str):
        """.role rename <@role> <new name>"""
        await role.edit(name=new_name)
        await ctx.send(f"✏️ Renamed role to `{new_name}`")

    @role.command(name="color")
    async def color(self, ctx: commands.Context, role: discord.Role, hex_color: str):
        """.role color <@role> <hex>"""
        await role.edit(colour=discord.Colour(int(hex_color.lstrip("#"), 16)))
        await ctx.send(f"🎨 Updated color for {role.mention}")

    @role.command(name="hoist")
    async def hoist(self, ctx: commands.Context, role: discord.Role, value: bool):
        """.role hoist <@role> <true|false>"""
        await role.edit(hoist=value)
        await ctx.send(f"✅ Hoist for {role.mention} set to `{value}`")

    @role.command(name="mentionable")
    async def mentionable(self, ctx: commands.Context, role: discord.Role, value: bool):
        """.role mentionable <@role> <true|false>"""
        await role.edit(mentionable=value)
        await ctx.send(f"✅ Mentionable for {role.mention} set to `{value}`")

    @role.command(name="perm")
    async def perm(
        self,
        ctx: commands.Context,
        channel: discord.abc.GuildChannel,
        role: discord.Role,
        permission: str,
        state: str,
    ):
        """.role perm <#channel> <@role> <permission_name> <allow|deny|neutral>

        Example: .role perm #general @Moderators manage_messages allow
        """
        permission = permission.lower()
        if permission not in VALID_PERMS:
            await ctx.send(
                f"⚠️ Unknown permission `{permission}`. "
                f"Examples: `send_messages`, `view_channel`, `manage_messages`, `connect`, `speak`."
            )
            return

        state = state.lower()
        overwrite = channel.overwrites_for(role)
        if state == "allow":
            setattr(overwrite, permission, True)
        elif state == "deny":
            setattr(overwrite, permission, False)
        elif state == "neutral":
            setattr(overwrite, permission, None)
        else:
            await ctx.send("⚠️ State must be `allow`, `deny`, or `neutral`.")
            return

        await channel.set_permissions(role, overwrite=overwrite)
        ch_name = getattr(channel, "mention", channel.name)
        await ctx.send(f"✅ Set `{permission}` → `{state}` for {role.mention} in {ch_name}")

    @role.command(name="perms")
    async def perms(self, ctx: commands.Context, channel: discord.abc.GuildChannel, role: discord.Role):
        """.role perms <#channel> <@role> — view current overwrites"""
        overwrite = channel.overwrites_for(role)
        pairs = [f"{name}: {val}" for name, val in overwrite if val is not None]
        desc = "\n".join(pairs) if pairs else "No overwrites set."
        embed = discord.Embed(
            title=f"Overwrites for {role.name} in #{channel.name}",
            description=desc,
            colour=discord.Colour.blurple(),
        )
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Roles(bot))
