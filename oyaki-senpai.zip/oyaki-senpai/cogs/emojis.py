import re

import aiohttp
import discord
from discord.ext import commands

EMOJI_RE = re.compile(r"<(a?):(\w+):(\d+)>")


class Emojis(commands.Cog):
    """Steal custom emojis from other servers into this one."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.session: aiohttp.ClientSession | None = None

    async def cog_load(self):
        self.session = aiohttp.ClientSession()

    async def cog_unload(self):
        if self.session:
            await self.session.close()

    async def _steal_one(self, ctx: commands.Context, animated: bool, name: str, emoji_id: str):
        ext = "gif" if animated else "png"
        url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{ext}"
        async with self.session.get(url) as resp:
            if resp.status != 200:
                await ctx.send(f"⚠️ Couldn't download emoji `{name}` (HTTP {resp.status})")
                return None
            data = await resp.read()
        try:
            return await ctx.guild.create_custom_emoji(
                name=name, image=data, reason=f"Stolen via bot by {ctx.author}"
            )
        except discord.HTTPException as e:
            await ctx.send(f"⚠️ Failed to add `{name}`: {e}")
            return None

    @commands.command(name="steal")
    async def steal(self, ctx: commands.Context, *, emojis: str = None):
        """
        .steal <:emoji1:> <:emoji2:> ...   — steal one or more emojis by pasting them
        or reply to a message containing custom emojis with just `.steal`
        """
        targets = []
        if emojis:
            targets.extend(EMOJI_RE.findall(emojis))

        if ctx.message.reference:
            ref_msg = ctx.message.reference.resolved
            if ref_msg is None:
                try:
                    ref_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                except discord.NotFound:
                    ref_msg = None
            if ref_msg:
                targets.extend(EMOJI_RE.findall(ref_msg.content))

        if not targets:
            await ctx.send(
                "⚠️ No custom emojis found. Paste the emoji(s) in the command, "
                "or reply to a message that contains them."
            )
            return

        added = []
        for animated_flag, name, emoji_id in targets:
            result = await self._steal_one(ctx, bool(animated_flag), name, emoji_id)
            if result:
                added.append(str(result))

        if added:
            await ctx.send(f"✅ Added {len(added)} emoji(s): " + " ".join(added))


async def setup(bot: commands.Bot):
    await bot.add_cog(Emojis(bot))
