import re

import discord
from discord.ext import commands

IMAGE_URL_RE = re.compile(r"(https?://\S+\.(?:png|jpe?g|gif|webp))(\?\S*)?\s*$", re.IGNORECASE)


class Embeds(commands.Cog):
    """Post a simple embed (description + optional image) to any channel."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="embed")
    async def embed(self, ctx: commands.Context, channel: discord.TextChannel, *, description: str):
        """
        .embed <#channel> <description text> [image url]
        You can also just attach an image to the command message instead of a URL.
        """
        image_url = None
        stripped = description.strip()
        match = IMAGE_URL_RE.search(stripped)
        if match:
            image_url = match.group(1)
            description = stripped[: match.start()].strip()
        elif ctx.message.attachments:
            image_url = ctx.message.attachments[0].url

        embed = discord.Embed(description=description, colour=discord.Colour.blurple())
        if image_url:
            embed.set_image(url=image_url)

        await channel.send(embed=embed)
        try:
            await ctx.message.add_reaction("✅")
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(Embeds(bot))
